# 2-3 minute video script (screen-record your VS Code + visuals)
**0:00** Hi, I'm Adeyemi, a Data Analytics intern at CodeAlpha. This is my EDA and visualization project.
**0:15** Dataset: Breast Cancer Wisconsin, 569 patients, 30 features. Show the script's first lines.
**0:35** Questions I asked first: balance, cleanliness, which features matter, significance, redundancy, outliers.
**0:55** Show the class balance chart: 63% benign, 37% malignant. Data is clean.
**1:15** Show distributions and boxplots: malignant tumours are larger, with more concave points.
**1:40** Show the effect-size chart: worst concave points is strongest. 26 of 30 features are significant (t-test).
**2:00** Show the heatmap: radius, perimeter and area are about 0.99 correlated, which is redundant.
**2:20** Show the outlier chart: error features are skewed.
**2:35** Next step: remove redundant features and build a classifier. Code is on GitHub, link in the post. Thanks!
