## Post 1: Internship status (tag @CodeAlpha)
Excited to share that I've joined @CodeAlpha as a Data Analytics Intern! 🚀
Over the coming weeks I'll be working on real-world projects in exploratory data analysis and data visualization with Python.
Grateful for the opportunity. Let's build! 📊
#CodeAlpha #DataAnalytics #Internship #Python #DataScience

## Post 2: Project video post (attach your video)
🔍 Task 2 & 3 done for my @CodeAlpha Data Analytics internship!
I explored the Breast Cancer Wisconsin dataset (569 tumours, 30 features) and found:
✅ Clean data: no missing values or duplicates
✅ Worst concave points and worst perimeter best separate malignant from benign tumours (Cohen's d above 2.3)
✅ 26 of 30 features differ significantly between classes (Welch t-test)
⚠️ 21 feature pairs are highly correlated (|r| > 0.9), so there is redundancy to handle before modelling
Built with Python, Pandas, Seaborn and SciPy.
🎥 Video walkthrough above. 💻 Code: <PASTE GITHUB LINK>
#CodeAlpha #DataAnalytics #EDA #DataVisualization #Python
