"""CodeAlpha Data Analytics Internship - Task 2 (EDA) + Task 3 (Data Visualization)
Dataset: Breast Cancer Wisconsin (Diagnostic), 569 tumours, 30 numeric features.
Run: python eda_visualization.py
"""
import pandas as pd, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
from scipy import stats
from sklearn.datasets import load_breast_cancer

sns.set_theme(style="whitegrid", palette="Set2")
OUT = "visuals/"

# ---------- 1. Load ----------
raw = load_breast_cancer(as_frame=True)
df = raw.frame.copy()
df["diagnosis"] = df["target"].map({0: "Malignant", 1: "Benign"})
df.drop(columns="target").to_csv("data/breast_cancer.csv", index=False)

# ---------- 2. Questions asked before analysis ----------
QUESTIONS = [
    "Is the dataset balanced between malignant and benign cases?",
    "Is the data clean (missing values, duplicates)?",
    "Which features differ most between malignant and benign tumours?",
    "Are the differences statistically significant?",
    "Which features are highly correlated (redundant)?",
    "Are there outliers/anomalies?",
]

# ---------- 3. Structure & quality ----------
print("Shape:", df.shape)
print(df.dtypes.value_counts())
print("Missing values:", int(df.isna().sum().sum()))
print("Duplicate rows:", int(df.duplicated().sum()))
print(df["diagnosis"].value_counts(normalize=True).round(3))
desc = df.describe().T
desc.to_csv("data/summary_statistics.csv")

# ---------- 4. Hypothesis tests (Welch t-test + Cohen's d) ----------
feats = [c for c in raw.feature_names]
rows = []
for f in feats:
    m = df.loc[df.diagnosis == "Malignant", f]; b = df.loc[df.diagnosis == "Benign", f]
    t, p = stats.ttest_ind(m, b, equal_var=False)
    sp = np.sqrt((m.var() + b.var()) / 2)
    rows.append((f, m.mean(), b.mean(), (m.mean() - b.mean()) / sp, p))
tests = pd.DataFrame(rows, columns=["feature", "mean_malignant", "mean_benign", "cohens_d", "p_value"])
tests["abs_d"] = tests.cohens_d.abs()
tests = tests.sort_values("abs_d", ascending=False)
tests.drop(columns="abs_d").to_csv("data/hypothesis_tests.csv", index=False)
top = tests.head(6).feature.tolist()
print("\nTop discriminating features:\n", tests.head(6)[["feature", "cohens_d", "p_value"]])
print("Significant at 5%:", int((tests.p_value < 0.05).sum()), "of", len(tests))

# ---------- 5. Outliers (IQR rule) ----------
out = {}
for f in feats:
    q1, q3 = df[f].quantile([.25, .75]); i = q3 - q1
    out[f] = int(((df[f] < q1 - 1.5 * i) | (df[f] > q3 + 1.5 * i)).sum())
out = pd.Series(out).sort_values(ascending=False)
print("\nMost outliers (IQR):\n", out.head(5))

# ---------- 6. Visuals ----------
# 6.1 class balance
fig, ax = plt.subplots(figsize=(5, 4))
cnt = df.diagnosis.value_counts()
sns.barplot(x=cnt.index, y=cnt.values, ax=ax)
for i, v in enumerate(cnt.values): ax.text(i, v + 5, f"{v} ({v/len(df):.0%})", ha="center")
ax.set(title="Diagnosis Distribution", ylabel="Patients", xlabel="")
plt.tight_layout(); plt.savefig(OUT + "01_class_balance.png", dpi=150); plt.close()

# 6.2 distributions of top features
fig, axes = plt.subplots(2, 3, figsize=(13, 7))
for ax, f in zip(axes.ravel(), top):
    sns.histplot(data=df, x=f, hue="diagnosis", kde=True, bins=30, ax=ax, stat="density", common_norm=False)
    ax.set_title(f)
plt.suptitle("Top 6 Features: Malignant vs Benign", fontsize=14)
plt.tight_layout(); plt.savefig(OUT + "02_top_feature_distributions.png", dpi=150); plt.close()

# 6.3 boxplots
fig, axes = plt.subplots(1, 4, figsize=(14, 4))
for ax, f in zip(axes, top[:4]):
    sns.boxplot(data=df, x="diagnosis", y=f, ax=ax); ax.set_xlabel(""); ax.set_title(f)
plt.tight_layout(); plt.savefig(OUT + "03_boxplots.png", dpi=150); plt.close()

# 6.4 effect size bar
fig, ax = plt.subplots(figsize=(8, 8))
t10 = tests.head(15).iloc[::-1]
ax.barh(t10.feature, t10.cohens_d.abs(), color=sns.color_palette("Set2")[1])
ax.set(title="Top 15 Features by Effect Size (|Cohen's d|)", xlabel="|Cohen's d|")
plt.tight_layout(); plt.savefig(OUT + "04_effect_sizes.png", dpi=150); plt.close()

# 6.5 correlation heatmap (mean features)
mean_cols = [c for c in feats if c.startswith("mean")]
fig, ax = plt.subplots(figsize=(9, 7))
sns.heatmap(df[mean_cols].corr(), annot=True, fmt=".2f", cmap="coolwarm", center=0, ax=ax, annot_kws={"size": 7})
ax.set_title("Correlation of Mean Features")
plt.tight_layout(); plt.savefig(OUT + "05_correlation_heatmap.png", dpi=150); plt.close()

# 6.6 pairplot
pp = sns.pairplot(df[top[:4] + ["diagnosis"]], hue="diagnosis", corner=True, plot_kws={"s": 12, "alpha": .6})
pp.figure.suptitle("Pairwise Relationships (Top 4 Features)", y=1.02)
pp.savefig(OUT + "06_pairplot.png", dpi=130); plt.close("all")

# 6.7 outlier counts
fig, ax = plt.subplots(figsize=(8, 6))
o = out.head(10).iloc[::-1]; ax.barh(o.index, o.values)
ax.set(title="Outliers per Feature (IQR rule, top 10)", xlabel="Count")
plt.tight_layout(); plt.savefig(OUT + "07_outliers.png", dpi=150); plt.close()

# ---------- 7. Redundancy ----------
c = df[feats].corr().abs(); up = c.where(np.triu(np.ones(c.shape), 1).astype(bool))
pairs = up.stack(); print("\nPairs with |r|>0.9:", int((pairs > 0.9).sum()))
print(pairs.sort_values(ascending=False).head(5))
